<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Autoloader.php' );

class Tribe__Events__Autoloader extends Tribe__Autoloader {}
