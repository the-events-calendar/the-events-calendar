If you are interested in contributing to translations, you can get started at https://translate.wordpress.org/projects/wp-plugins/the-events-calendar/stable/

On that site you can also find the .po translation files for doing local translations. We do not include these in the plugin itself to save space.